module.exports = del_Active_obj_query({
    isActive: true,
    delStatus: false,
  });
  
  module.exports = default_omit_arr(['updated_by', 'updated_on', 'delete_status',]);
  